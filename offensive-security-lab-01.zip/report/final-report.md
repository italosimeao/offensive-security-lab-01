# Final Report

## Vulnerability
Samba usermap_script Remote Command Execution

## Exploitation Result
A reverse shell session was established successfully.

## Privilege Level
Root

## Impact
Full system compromise allowing command execution, file access, and persistence possibilities.
