# Offensive Security Lab 01 – Samba Exploitation

## Objective
This project documents the exploitation of a Samba service vulnerability in a controlled lab environment for educational and cybersecurity training purposes.

## Lab Environment
- Kali Linux (Attacker)
- Metasploitable (Target)
- VirtualBox
- Host-Only Network

## Tools Used
- Nmap
- Metasploit Framework
- Netcat
- Linux Terminal

## Methodology
1. Reconnaissance
2. Enumeration
3. Exploitation
4. Reverse Shell Access
5. Basic Post-Exploitation

## Results
Successful remote exploitation resulted in root-level shell access, demonstrating full system compromise.

## Ethical Disclaimer
This project was conducted in a fully controlled lab environment using intentionally vulnerable machines for educational purposes only.
